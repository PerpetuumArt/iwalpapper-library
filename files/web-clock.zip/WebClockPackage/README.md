# Web Clock (example web wallpaper package)

This folder is the reference web pack: it loads through the same validated package path
a community author uses, and it only ever talks to the host through the documented
bridge.

```
WebClockPackage/
  manifest.json    schema 1 manifest, renderer "web", entry "index.html"
  index.html       the page; no inline script or style, so the content policy fits
  app.js           the creator-facing half of the bridge, and the clock itself
  styles.css       the page fills the surface and nothing scrolls
  preview.png      original drawing used as the pack thumbnail and the pause fallback
```

Regenerate every file in this folder from scratch with:

```sh
swift scripts/generate-web-clock-package.swift Examples/WebClockPackage
```

The manifest, the page, the stylesheet, the script and the preview are all output of
that script; it is the source of truth, and no third-party art, font file or code is
copied in.

## Trying it

Web wallpapers are **off by default** in this build. Importing and inspecting the
package works either way; running it needs the explicit development opt-in, because
this version cannot yet prove that a web wallpaper is denied every route to the
network (see [`docs/web-packages.md`](../../docs/contracts/web-packages.md), "What is not
proven").

```sh
bash scripts/build-app.sh

# Import and run it in one isolated library, with the opt-in set.
IWALPAPPER_ENABLE_WEB_EXECUTION=1 \
IWALPAPPER_QA_LIBRARY_ROOT=/tmp/iwalpapper-web-qa \
IWALPAPPER_QA_LIBRARY_IMPORT="$PWD/Examples/WebClockPackage" \
IWALPAPPER_QA_COVERAGE_PAUSE=off \
IWALPAPPER_QA_DUMP_SECONDS=4 IWALPAPPER_QA_EXIT=1 \
    build/iWalpapper.app/Contents/MacOS/iWalpapper
```

`IWALPAPPER_QA_WEB_PROBE=1` drives the same wallpaper through playing, pause, resume
and stop, printing the renderer's diagnostics and the app's helper processes at each
step. Without the opt-in variable the same run imports the package and reports the
refusal instead.

## What the page uses

The page never receives a path, a URL, a native object or a token. It gets a bounded
state document and it can send three message kinds back:

| Direction | Name | Payload |
|---|---|---|
| Host → page | `initialize` | `apiVersion`, `packageID`, `settings`, `size`, `time`, `quality`, `resumed` |
| Host → page | `settings` | the host-owned settings document |
| Host → page | `context` | `size`, `time`, `quality` |
| Host → page | `quality` | `full` or `reduced` |
| Host → page | `pause`, `resume`, `dispose` | none |
| Page → host | `ready` | none; asks for `initialize` |
| Page → host | `error` | one bounded string |
| Page → host | `diagnostic` | one bounded string |

The `settings` document is the same bounded, validated document the native clock
reads - `seconds`, `size`, `position`, `dialColor`, `backgroundColor`, `ticks`,
`numerals`, `handStyle`, `secondHandStyle`, `timeZone`, `date` - which is why this page
can be restyled from the host without shipping a second settings format. Every field is
documented in [`docs/package-format.md`](../../docs/contracts/package-format.md).

## Provenance and licensing

Every asset in this folder is original output of
`scripts/generate-web-clock-package.swift`. No licence has been selected for this
example, for the other examples, for the app or for the SDK. The manifest's required
`license` field therefore carries the neutral declaration
`"name": "License pending selection"` with no URL: it records that the question is open
and grants nothing.
