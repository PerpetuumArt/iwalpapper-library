/*
 * Web Clock — the reference web wallpaper package.
 *
 * Creator-facing API in three calls:
 *
 *   window.iwalpapper.on("initialize", handler)   full state: settings, size, time
 *   window.iwalpapper.on("settings", handler)     the host-owned settings changed
 *   window.iwalpapper.on("context", handler)      size, time zone or quality changed
 *   window.iwalpapper.on("pause" / "resume" / "dispose", handler)
 *   window.iwalpapper.ready()                     ask the host to send the state
 *   window.iwalpapper.reportError(text)           report a bounded diagnostic
 *
 * The host sends the same settings document the native clock reads, so every control
 * below is validated before the page ever sees it. The page still re-checks, because
 * a package should not trust its own inputs either.
 */
(function () {
  "use strict";

  var canvas = document.getElementById("face");
  var context = canvas.getContext("2d");
  var host = window.iwalpapper;
  var timer = null;
  var frame = null;
  var lastDrawnSecond = -1;
  var pixelRatio = 1;
  var width = 0;
  var height = 0;
  var reportedFirstFrame = false;

  var DEFAULTS = {
    seconds: "stepped",
    size: 0.35,
    position: { x: 0.5, y: 0.5 },
    dialColor: "#F5F6F8",
    backgroundColor: "#0B0F14",
    ticks: "minute",
    numerals: "arabic",
    timeZone: "system",
    date: "medium"
  };

  function pick(value, allowed, fallback) {
    return allowed.indexOf(value) === -1 ? fallback : value;
  }

  function number(value, minimum, maximum, fallback) {
    return typeof value === "number" && isFinite(value) && value >= minimum && value <= maximum
      ? value
      : fallback;
  }

  function color(value, fallback) {
    return typeof value === "string" && /^#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?$/.test(value) ? value : fallback;
  }

  function knownTimeZone(value) {
    if (typeof value !== "string" || value === "" || value === "system") { return "system"; }
    try {
      new Intl.DateTimeFormat("en-US", { timeZone: value }).format(new Date());
      return value;
    } catch (error) {
      return "system";
    }
  }

  function currentSettings() {
    var state = host && host.state ? host.state : null;
    var document = state && state.settings && typeof state.settings === "object" ? state.settings : {};
    var position = document.position && typeof document.position === "object" ? document.position : {};
    return {
      seconds: pick(document.seconds, ["stepped", "smooth", "hidden"], DEFAULTS.seconds),
      size: number(document.size, 0.05, 1, DEFAULTS.size),
      position: {
        x: number(position.x, 0, 1, DEFAULTS.position.x),
        y: number(position.y, 0, 1, DEFAULTS.position.y)
      },
      dialColor: color(document.dialColor, DEFAULTS.dialColor),
      backgroundColor: color(document.backgroundColor, DEFAULTS.backgroundColor),
      ticks: pick(document.ticks, ["none", "hour", "minute"], DEFAULTS.ticks),
      numerals: pick(document.numerals, ["none", "arabic", "roman"], DEFAULTS.numerals),
      timeZone: knownTimeZone(document.timeZone),
      date: pick(document.date, ["none", "short", "medium", "long"], DEFAULTS.date)
    };
  }

  function hostTimeZone() {
    var state = host && host.state ? host.state : null;
    var time = state && state.time && typeof state.time === "object" ? state.time : {};
    return knownTimeZone(time.timeZoneIdentifier);
  }

  function resolvedTimeZone(settings) {
    return settings.timeZone === "system" ? hostTimeZone() : settings.timeZone;
  }

  function zonedParts(date, zone) {
    var formatter = new Intl.DateTimeFormat("en-US", {
      timeZone: zone === "system" ? undefined : zone,
      hour12: false,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });
    var parts = {};
    formatter.formatToParts(date).forEach(function (part) { parts[part.type] = part.value; });
    return {
      hour: parseInt(parts.hour, 10) % 24,
      minute: parseInt(parts.minute, 10),
      second: parseInt(parts.second, 10),
      millisecond: date.getMilliseconds()
    };
  }

  function dateText(date, zone, style) {
    if (style === "none") { return ""; }
    try {
      return new Intl.DateTimeFormat(undefined, {
        dateStyle: style,
        timeZone: zone === "system" ? undefined : zone
      }).format(date);
    } catch (error) {
      return "";
    }
  }

  function resize() {
    pixelRatio = window.devicePixelRatio || 1;
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.max(Math.round(width * pixelRatio), 1);
    canvas.height = Math.max(Math.round(height * pixelRatio), 1);
    canvas.style.width = width + "px";
    canvas.style.height = height + "px";
  }

  function pointOn(angle, distance, centerX, centerY) {
    var radians = (angle - 90) * Math.PI / 180;
    return { x: centerX + Math.cos(radians) * distance, y: centerY + Math.sin(radians) * distance };
  }

  function hand(ctx, angle, length, tail, lineWidth, centerX, centerY, tint) {
    ctx.save();
    ctx.strokeStyle = tint;
    ctx.lineWidth = lineWidth;
    ctx.lineCap = "round";
    ctx.beginPath();
    var base = pointOn(angle, -tail, centerX, centerY);
    var tip = pointOn(angle, length, centerX, centerY);
    ctx.moveTo(base.x, base.y);
    ctx.lineTo(tip.x, tip.y);
    ctx.stroke();
    ctx.restore();
  }

  function draw() {
    var settings = currentSettings();
    var zone = resolvedTimeZone(settings);
    var date = new Date();
    var parts = zonedParts(date, zone);
    var radius = Math.min(width, height) * settings.size / 2;
    var centerX = Math.min(Math.max(width * settings.position.x, radius), width - radius);
    var centerY = Math.min(Math.max(height * settings.position.y, radius), height - radius);
    var ticks = settings.ticks;
    var numerals = settings.numerals;

    context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    context.clearRect(0, 0, width, height);
    context.fillStyle = settings.backgroundColor;
    context.fillRect(0, 0, width, height);

    context.beginPath();
    context.arc(centerX, centerY, radius, 0, Math.PI * 2);
    context.fillStyle = settings.dialColor;
    context.fill();

    if (ticks !== "none") {
      context.save();
      context.strokeStyle = settings.backgroundColor;
      context.lineCap = "butt";
      for (var index = 0; index < 60; index += 1) {
        var isHour = index % 5 === 0;
        if (ticks === "hour" && !isHour) { continue; }
        var length = isHour ? radius * 0.11 : radius * 0.055;
        var lineWidth = isHour ? Math.max(radius * 0.028, 1.5) : Math.max(radius * 0.012, 1);
        var outer = pointOn(index * 6, radius * 0.97, centerX, centerY);
        var inner = pointOn(index * 6, radius * 0.97 - length, centerX, centerY);
        context.beginPath();
        context.lineWidth = lineWidth;
        context.moveTo(inner.x, inner.y);
        context.lineTo(outer.x, outer.y);
        context.stroke();
      }
      context.restore();
    }

    if (numerals !== "none") {
      context.save();
      context.fillStyle = settings.backgroundColor;
      context.font = Math.max(radius * 0.155, 6) + "px Helvetica, Arial, sans-serif";
      context.textAlign = "center";
      context.textBaseline = "middle";
      var roman = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"];
      for (var mark = 0; mark < 12; mark += 1) {
        var label = numerals === "roman" ? roman[mark] : String(mark === 0 ? 12 : mark);
        var position = pointOn(mark * 30, radius * 0.75, centerX, centerY);
        context.fillText(label, position.x, position.y);
      }
      context.restore();
    }

    var text = dateText(date, zone, settings.date);
    if (text !== "") {
      context.save();
      context.fillStyle = settings.backgroundColor;
      context.font = Math.max(radius * 0.085, 6) + "px Helvetica, Arial, sans-serif";
      context.textAlign = "center";
      context.textBaseline = "middle";
      context.fillText(text, centerX, centerY - radius * 0.42);
      context.restore();
    }

    var seconds = settings.seconds === "smooth"
      ? parts.second + parts.millisecond / 1000
      : parts.second;
    var minutes = parts.minute + seconds / 60;
    var hours = (parts.hour % 12) + minutes / 60;

    hand(context, hours * 30, radius * 0.5, radius * 0.06, Math.max(radius * 0.055, 2), centerX, centerY, settings.backgroundColor);
    hand(context, minutes * 6, radius * 0.72, radius * 0.08, Math.max(radius * 0.04, 1.5), centerX, centerY, settings.backgroundColor);
    if (settings.seconds !== "hidden") {
      hand(context, seconds * 6, radius * 0.84, radius * 0.18, Math.max(radius * 0.016, 1), centerX, centerY, settings.backgroundColor);
    }

    context.beginPath();
    context.arc(centerX, centerY, Math.max(radius * 0.035, 2), 0, Math.PI * 2);
    context.fillStyle = settings.backgroundColor;
    context.fill();
    context.beginPath();
    context.arc(centerX, centerY, Math.max(radius * 0.016, 1), 0, Math.PI * 2);
    context.fillStyle = settings.dialColor;
    context.fill();

    lastDrawnSecond = parts.second;
  }

  function stop() {
    if (timer !== null) {
      clearTimeout(timer);
      clearInterval(timer);
      timer = null;
    }
    if (frame !== null) {
      cancelAnimationFrame(frame);
      frame = null;
    }
  }

  function drawSafely() {
    try {
      draw();
      if (!reportedFirstFrame && host && host.reportDiagnostic) {
        reportedFirstFrame = true;
        host.reportDiagnostic(
          "web clock drew " + Math.round(width) + "x" + Math.round(height)
            + " seconds=" + currentSettings().seconds
        );
      }
    } catch (error) {
      if (host && host.reportError) { host.reportError("draw failed: " + error.message); }
    }
  }

  function tick() {
    var settings = currentSettings();
    if (settings.seconds === "smooth") {
      drawSafely();
      frame = requestAnimationFrame(tick);
      return;
    }
    var now = Date.now();
    var period = settings.seconds === "hidden" ? 60000 : 1000;
    if (settings.seconds === "hidden" || Math.floor(now / 1000) !== lastDrawnSecond) {
      drawSafely();
    }
    timer = setTimeout(tick, period - (now % period) + 4);
  }

  function start() {
    stop();
    resize();
    var settings = currentSettings();
    if (settings.seconds === "smooth") {
      frame = requestAnimationFrame(tick);
    } else {
      drawSafely();
      timer = setTimeout(tick, settings.seconds === "hidden" ? 60000 - (Date.now() % 60000) + 4 : 1000 - (Date.now() % 1000) + 4);
    }
  }

  function restart() {
    start();
  }

  // Reports the settings the page currently believes it has, read back through the
  // public state object, so a host change can be verified from outside the page.
  function reportState(reason) {
    if (!host || !host.reportDiagnostic) { return; }
    var settings = currentSettings();
    host.reportDiagnostic(
      "web clock " + reason + " seconds=" + settings.seconds + " size=" + settings.size.toFixed(2)
    );
  }

  window.addEventListener("resize", function () {
    resize();
    drawSafely();
  });

  if (host) {
    host.on("initialize", function () { reportState("initialize"); restart(); });
    host.on("settings", function () { reportState("settings"); restart(); });
    host.on("context", restart);
    host.on("quality", restart);
    host.on("pause", stop);
    host.on("resume", start);
    host.on("dispose", stop);
    // The page is ready: the host replies with the current state, size, clock and
    // time zone, and this handler draws the first frame.
    host.ready();
  } else {
    start();
  }
})();